# Core Skills Extraction Rules

## Normalization

Use canonical capitalization and spelling:

- javascript -> JavaScript
- typescript -> TypeScript
- node, nodejs, node.js -> Node.js
- reactjs, react.js -> React
- nextjs, next.js -> Next.js
- vuejs, vue.js -> Vue.js
- angularjs only when specifically legacy AngularJS; otherwise Angular
- dotnet, .net core -> .NET, .NET Core when version context matters
- c sharp, c# -> C#
- golang -> Go
- postgres, postgresql -> PostgreSQL
- mongo, mongodb -> MongoDB
- ms sql, sql server, microsoft sql server -> SQL Server
- mysql -> MySQL
- rest, restful, rest api -> REST APIs
- graphql -> GraphQL
- amazon web services -> AWS
- google cloud platform -> GCP
- microsoft azure -> Azure
- k8s -> Kubernetes
- ci cd, cicd -> CI/CD
- github actions -> GitHub Actions
- gitlab ci -> GitLab CI
- machine learning -> Machine Learning
- artificial intelligence -> AI
- large language models -> LLMs

Keep official product names where useful: Amazon S3, AWS Lambda, Amazon EC2, Amazon RDS, Azure DevOps, Google BigQuery, Cloud Run, Cloud Functions.

## Deduplication Rules

- Keep only the strongest canonical version of the same technology.
- Do not include both a parent and child term unless both add value. For example, keep `AWS` plus specific services only if the services are meaningful in the candidate's work.
- Do not repeat language and framework variants unless they indicate distinct capabilities, such as `Java`, `Spring Boot`, and `Hibernate`.
- Merge equivalent API terms: prefer `REST APIs` over `RESTful Services` unless the source strongly uses another term.

## Obsolete or Low-Value Filtering

Usually remove or de-prioritize:

- Very old or weak tools: CVS, SVN, Bower, Grunt, Gulp, jQuery, Flash, Dreamweaver, Visual Basic 6, Classic ASP, WebForms.
- Office/productivity tools: Microsoft Office, Excel, Word, PowerPoint, Outlook.
- Operating systems unless strategically relevant: Windows, macOS, Linux can remain only if infrastructure, DevOps, or systems engineering is central.
- Generic IDEs/editors unless specifically requested: VS Code, Eclipse, IntelliJ IDEA, Visual Studio.
- Basic protocols unless strategically relevant: FTP, SMTP, HTTP.

Keep legacy technologies only when they are clearly important to the candidate's positioning, such as enterprise modernization, migration, mainframe integration, embedded systems, or long-term maintenance of legacy platforms.

## Strategic Ordering Examples

Good invisible order for backend/cloud profile:

`Java, Kotlin, Python, Spring Boot, Node.js, REST APIs, GraphQL, Microservices, Event-Driven Architecture, Distributed Systems, AWS, Azure, Docker, Kubernetes, Terraform, GitHub Actions, Jenkins, CI/CD, PostgreSQL, MongoDB, Redis, Kafka, Elasticsearch, JUnit, Mockito, TDD, Agile, Scrum`

Good invisible order for AI/backend profile:

`Python, TypeScript, Node.js, FastAPI, Django, REST APIs, GraphQL, Microservices, AWS, GCP, Docker, Kubernetes, Terraform, CI/CD, PostgreSQL, MongoDB, Redis, Kafka, Machine Learning, AI, LLMs, LangChain, OpenAI API, Vector Databases, Pinecone, PyTorch, TensorFlow, MLOps, Agile, Scrum`

Good invisible order for full-stack profile:

`JavaScript, TypeScript, Node.js, Python, React, Next.js, Angular, HTML5, CSS3, REST APIs, GraphQL, Microservices, AWS, Docker, Kubernetes, GitHub Actions, CI/CD, PostgreSQL, MySQL, MongoDB, Redis, Jest, Cypress, Agile, Scrum`

## Output Examples

Example output:

```markdown
CORE SKILLS
Java, Kotlin, Python, Spring Boot, Node.js, REST APIs, GraphQL, Microservices, Event-Driven Architecture, Distributed Systems, AWS, Docker, Kubernetes, Terraform, Jenkins, GitHub Actions, CI/CD, PostgreSQL, MongoDB, Redis, Kafka, Elasticsearch, JUnit, Mockito, TDD, Agile, Scrum
```

Example output:

```markdown
CORE SKILLS
Python, TypeScript, Node.js, FastAPI, Django, REST APIs, Microservices, Serverless Architecture, AWS, GCP, Docker, Kubernetes, Terraform, GitHub Actions, CI/CD, PostgreSQL, MongoDB, Redis, Kafka, Machine Learning, AI, LLMs, LangChain, OpenAI API, Vector Databases, Pinecone, MLOps, PyTest, Agile, Scrum
```

## Final Validation Checklist

Before responding, verify:

- The response has exactly two visible parts: the fixed title and one paragraph.
- The title is exactly `CORE SKILLS`.
- The paragraph is comma-separated.
- There are no visible category labels.
- There are no bullets, tables, explanations, or extra notes.
- Technologies are deduplicated and normalized.
- The list is strategically ordered from core engineering to cloud/devops/data/practices.
