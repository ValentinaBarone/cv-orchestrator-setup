---
name: core-skills-extractor
description: "extraction, filtering, deduplication, and strategic categorization of technical core skills from engineering cvs, resumes, professional profiles, or pasted experience/skills text. use when the user provides a cv, resume, pdf, word document, txt file, or raw profile text and needs only a clean core skills section in markdown, with one fixed title and one continuous comma-separated paragraph of technologies. focus on software engineering, backend, cloud, ai, devops, databases, frameworks, tools, and architecture keywords while removing duplicates, noise, and obsolete or weak items."
---

# Core Skills Extractor

## Objective

Extract and standardize the technical skills section for engineering profiles. Read the full CV, resume, profile, experience section, or raw skills list, then return only a polished `CORE SKILLS` block suitable for a professional resume.

The output must be concise, keyword-dense, strategically ordered, and formatted as a single continuous paragraph of comma-separated technologies. Do not include explanations, bullets, tables, categories, notes, or confidence commentary.

## Required Output Contract

Always return exactly this structure:

```markdown
CORE SKILLS
Technology 1, Technology 2, Technology 3, Technology 4, Technology 5
```

Rules:
- The title must be exactly `CORE SKILLS` in uppercase.
- After the title, output one continuous paragraph only.
- Separate all technologies with commas only.
- Do not use visible category labels, subtitles, bullets, pipes, semicolons, parentheses for categories, or tables.
- Do not add intro text, closing text, explanations, warnings, or markdown headings such as `#`.
- Do not output soft skills unless they are explicit technical practices, such as Agile, Scrum, CI/CD, DevOps, SRE, TDD, or Microservices.

## Extraction Workflow

1. Scan the complete input for technical keywords across experience, projects, skills, certifications, education, and summaries.
2. Prefer technologies that are supported by work experience, repeated usage, recent roles, or strategic relevance.
3. Normalize names and capitalization using `references/core-skills-rules.md`.
4. Remove duplicates, near-duplicates, generic noise, and weak resume filler.
5. Remove obsolete or low-value items unless they are central to the candidate's career or relevant to legacy enterprise work.
6. Order the remaining skills using invisible logical groups, but never print the group labels.
7. Return only the final `CORE SKILLS` block.

## Invisible Ordering Strategy

Internally arrange technologies in this order, while keeping the output as one paragraph:

1. Programming languages and backend platforms
2. Backend frameworks, APIs, and architecture patterns
3. Frontend or mobile technologies, only if relevant
4. Cloud platforms and cloud-native services
5. DevOps, CI/CD, containers, orchestration, observability, and IaC
6. Databases, data platforms, messaging, and search
7. AI, ML, data science, or automation technologies when present
8. Testing, quality, security, and engineering practices
9. Project delivery methodologies and collaboration tools only when strategically useful

## Inclusion Rules

Include:
- Programming languages, frameworks, libraries, runtimes, cloud platforms, databases, messaging systems, DevOps tools, testing tools, architecture patterns, and AI/data technologies.
- Common abbreviations when they are market-relevant, such as AWS, GCP, Azure, CI/CD, REST APIs, GraphQL, Kubernetes, Docker, Terraform, Kafka, SQL, NoSQL.
- Architecture and engineering practices when they strengthen the profile, such as Microservices, Event-Driven Architecture, Distributed Systems, Serverless, TDD, Clean Architecture, Domain-Driven Design.

Exclude:
- Personal traits: leadership, communication, ownership, teamwork, problem-solving.
- Business-only terms unless tied to a technical domain.
- Duplicates and variants that add no value, such as `Node`, `Node.js`, and `NodeJS` all appearing together.
- Generic tool categories such as `programming`, `software`, `databases`, `cloud`, `tools`, or `frameworks`.
- Outdated tools or technologies if they are minor, old, or unsupported by the candidate's recent experience.

## Quality Bar

The final paragraph should feel like a curated senior engineering core skills section, not a raw keyword dump. Favor strong, recognizable technologies and avoid overloading the paragraph with every minor tool mentioned once.

For most senior technical profiles, aim for roughly 25 to 55 skills. Use fewer if the source is limited. Use more only when the CV clearly supports broad technical depth.

## Reference

Use `references/core-skills-rules.md` for normalization, filtering, ordering examples, and sample outputs.
