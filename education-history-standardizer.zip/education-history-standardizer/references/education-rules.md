# Education Rules

## Reverse Chronological Ordering
Order education records by the latest explicit year in the record:
1. `Present` or ongoing programs first.
2. Highest end year next.
3. If only a single year is available, use that year for ordering.
4. If no year is available, place the item after dated records.
5. For ties, put the highest degree level first: PhD, Doctorate, Master's, MBA, Postgraduate, Bachelor's, Associate/Technical.

## Degree Normalization
Normalize common multilingual degree names while keeping accuracy:
- `Ingeniería en Sistemas`, `Ingeniero en Sistemas`, `Systems Engineering` -> `Systems Engineering Degree` or `Bachelor's Degree in Systems Engineering`, depending on the source.
- `Licenciatura en ...` -> `Bachelor's Degree in ...` when used as a university degree.
- `Maestría`, `Master`, `MSc`, `MS` -> `Master's Degree in ...` when the field is known, or `Master's Degree` when unknown.
- `MBA` -> `Master of Business Administration (MBA)`.
- `Doctorado`, `PhD`, `Ph.D.` -> `Doctorate / PhD in ...` when the field is known, or `Doctorate / PhD` when unknown.
- `Especialización`, `Postgrado`, `Postgraduate Program` -> `Postgraduate Degree in ...` when clearly university-level.

Do not upgrade a credential. For example, do not convert a short course into a postgraduate degree.

## Institution Normalization
- Use the full institution name when available.
- Preserve known acronyms only when they are part of the recognized institution name or appear with the full name.
- Remove department, faculty, campus, or school names unless they are the only institution-like data available.
- Do not add country or city unless it is present in the input and part of the institution line. The required output has no separate location field.

## Date Normalization
- Convert date ranges to `YYYY - YYYY`.
- Convert ongoing studies to `YYYY - Present` only when the source says present, current, ongoing, en curso, actualidad, or equivalent.
- If month names appear, drop months and keep years only.
- If the source gives expected graduation, use `YYYY - Present` only if the program is explicitly ongoing; otherwise use the expected year alone.
- If dates are missing, use `Not specified`.

## Deduplication
When the same degree appears multiple times:
- Keep the most complete version.
- Prefer records with degree + institution + years.
- Merge missing details only if they clearly refer to the same program.
- Do not output both abbreviated and expanded versions of the same credential.

## Examples

Input:
```
Education
2019-2021 Universidad de Buenos Aires - Maestría en Ciencia de Datos
Ingeniería en Sistemas, UTN, 2010 - 2015
AWS Certified Solutions Architect
```

Output:
```markdown
EDUCATION
• Master's Degree in Data Science — Universidad de Buenos Aires — 2019 - 2021
• Systems Engineering Degree — Universidad Tecnológica Nacional (UTN) — 2010 - 2015
```

Input:
```
Formación Académica: MBA, Universidad Austral, graduado 2023. Licenciatura en Informática, Universidad Nacional de La Plata.
```

Output:
```markdown
EDUCATION
• Master of Business Administration (MBA) — Universidad Austral — 2023
• Bachelor's Degree in Computer Science — Universidad Nacional de La Plata — Not specified
```
