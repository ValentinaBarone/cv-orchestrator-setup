---
name: education-history-standardizer
description: extraction, standardization, and reverse chronological ordering of university education history from cvs, resumes, professional profiles, or pasted education text. use when the user provides pdf, word, txt, or raw resume/profile content and needs only a clean education section in markdown under the fixed title education. focus on official university degrees, postgraduate programs, master's degrees, doctorates, institutions, locations when available, and study years while excluding courses, bootcamps, certificates, workshops, and unrelated training unless explicitly requested.
---

Education Extractor (Strict Format & Context-Based Contract)
Objective:
Analyze the provided resume, CV, or academic text and generate ONLY the standardized "EDUCATION" section in Markdown. Format all higher education degrees into a clean, unified timeline without hallucinating or expanding unknown abbreviations.

Required Output Structure:
EDUCATION
• [Degree Name] — [Institution Name] — [Year - Year]

Strict Formatting Rules:
1. Title: Must be exactly "EDUCATION" in uppercase.
2. Formatting: Output must be a simple list using standard bullet characters (•). Do NOT use asterisks (*) or numbered lists.
3. Separators: Each element within the bullet point (Degree, Institution, and Dates) must be separated strictly by a space, an em-dash, and another space: " — ".
4. Date Separator: The range of years must use a standard hyphen with spaces: " - ". Example: 2021 - 2025.
5. NO BOLD TEXT: Do NOT use bold text (**) anywhere in this section. All text must be plain text.
6. No intro/outro text: Return ONLY the uppercase title and the bullet points.

Strict Naming Alignment (Context-Based Only):
- Rely STRICTLY on the text provided by the user. Do not invent, guess, or hallucinate full names for abbreviations or acronyms if they are not explicitly written in the input text.
- If the user provides the full name (e.g., "Universidade de São Paulo (USP)"), keep it exactly as provided.
- If the user provides only an acronym or abbreviation (e.g., "MIT" or "XYZ University"), preserve the user's exact wording. Do not alter or try to expand the institution name.
- Standardize ONLY the degree prefix style to maintain executive resume quality:
  * Ensure Doctorates start with "PhD in..."
  * Ensure Master's degrees start with "Master’s Degree in..."
  * Ensure Bachelor's degrees start with "Bachelor’s Degree in..."
  * Ensure Postgraduates start with "Postgraduate Certificate in..."

Timeline & Ordering Rules:
- Sort all entries strictly in reverse chronological order (most recent start/end date at the top).
- Exclude short courses, vendor certifications (like AWS, Databricks, IBM), or online platform certificates. Focus strictly on university or higher education academic degrees.
