---
name: certifications-standardizer
description: extraction, cleanup, normalization, and reverse chronological ordering of certifications, technical courses, industry credentials, badges, verification links, and approved technical training from cvs, resumes, professional profiles, pdfs, word documents, txt files, or pasted notes. use when the user needs only a clean certifications section in markdown under the fixed title certifications, with bullet lines showing certification name and year when available. prioritize industry certifications from aws, google, microsoft, ibm, databricks, kubernetes, scrum, security, cloud, data, ai, devops, and reputable learning platforms while excluding unrelated education, work history, skills lists, and nontechnical noise.
---

Certifications Extractor (Strict Format Contract)
Objective:
Analyze the provided text, resume, or credentials list and generate ONLY the standardized "CERTIFICATIONS" section in Markdown. Format technical certifications, vendor credentials, and specialized courses into a clean, unified list.

Required Output Structure:
CERTIFICATIONS
• [Certification Name] — [Year]
• [Certification Name]

Strict Formatting Rules:
1. Title: Must be exactly "CERTIFICATIONS" in uppercase.
2. Formatting: Output must be a simple list using standard bullet characters (•). Do NOT use asterisks (*) or numbered lists.
3. Separators: If the year is available, separate the certification name and the year strictly by a space, an em-dash, and another space: " — ".
4. No Missing Dates: If an entry does not contain a specific year, output ONLY the certification name. Do not append a trailing dash or empty spaces.
5. NO BOLD TEXT: Do NOT use bold text (**) anywhere in this section. All text must be plain text.
6. No intro/outro text: Return ONLY the uppercase title and the bullet points.

Timeline & Ordering Rules:
- Sort all entries with known dates strictly in reverse chronological order (most recent years at the top).
- Entries without an explicit year should be placed logically below the dated entries.
- Focus strictly on technical certifications, cloud vendor badges, or engineering-specific coursework (exclude university degrees, which belong to Education).
