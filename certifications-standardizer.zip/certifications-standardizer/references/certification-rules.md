# Certification Rules

Use this reference when normalizing noisy certification, course, or badge data.

## Canonical Naming

Prefer concise, recruiter-friendly names. Keep official vendor acronyms and product names.

Examples:

- `AWS Certified Solutions Architect - Associate` -> `AWS Certified Solutions Architect – Associate`
- `AWS Cloud Practitioner Essentials course` -> `AWS Cloud Practitioner Essentials`
- `Google Cloud Professional Data Engineer` -> `Google Cloud Professional Data Engineer`
- `IBM Data Science Professional Certificate` -> `IBM Data Science Professional Certificate`
- `Databricks Lakehouse Fundamentals Badge` -> `Databricks Lakehouse Fundamentals`
- `Microsoft Certified: Azure Fundamentals` -> `Microsoft Certified: Azure Fundamentals`
- `CKA: Certified Kubernetes Administrator` -> `Certified Kubernetes Administrator (CKA)`
- `Deep Learning Specialization by deeplearning.ai` -> `Deep Learning Specialization – DeepLearning.AI`

Use an en dash inside official certification levels only when it improves readability, but always use the required em dash separator before the year in the final output.

## Year Extraction

Use the year from these signals, in priority order:

1. Completed, completion date, finished, passed, awarded, issued, obtained.
2. Certificate date or badge issued date.
3. Exam passed date.
4. Course end date.
5. Expiration date only when no issue/completion date exists and the source does not provide a better date.

If a date appears as `Mar 2024`, `03/2024`, `2024-03-01`, or `2024`, output only `2024`.

If a credential has both issue and expiration dates, use the issue year.

## Deduplication

Treat these as duplicates when they clearly refer to the same credential:

- Same vendor + same certification level + same specialization.
- Same course name with minor platform wording differences.
- Same badge name with and without verification URL.
- Same certification repeated in multiple resume sections.

When duplicates differ:

- Keep the most complete official name.
- Keep the most recent valid issue/completion year.
- Drop credential IDs, URLs, and repeated provider boilerplate.

## Strategic Ordering Within Same Year

When several items share the same year, order them by perceived CV value:

1. Major cloud/vendor certifications.
2. Data, AI, ML, analytics, and platform certifications.
3. DevOps, Kubernetes, infrastructure, and security credentials.
4. Programming language/framework courses.
5. Short learning-platform courses.

## Output Examples

Input:

```text
AWS Certified Solutions Architect Associate, issued May 2023
Databricks Lakehouse Fundamentals badge - Credential ID abc123
Google Cloud Skill Boost: Serverless Firebase Development, completed 2021
Udemy React course
```

Output:

```markdown
CERTIFICATIONS

• AWS Certified Solutions Architect – Associate — 2023
• Google Cloud Serverless Firebase Development — 2021
• Databricks Lakehouse Fundamentals
• React Course
```

Input:

```text
IBM Data Science Professional Certificate (Coursera) 2020
AWS Cloud Practitioner 2022
AWS Cloud Practitioner - 2021
```

Output:

```markdown
CERTIFICATIONS

• AWS Certified Cloud Practitioner — 2022
• IBM Data Science Professional Certificate — 2020
```

Input:

```text
Skills: Python, Java, AWS, Kubernetes
Education: Bachelor of Computer Science, 2016
```

Output:

```markdown
CERTIFICATIONS
```
