# Language Level Rules

## Language name normalization
Normalize common language names into English:

- ingles, inglés, english -> English
- espanol, español, spanish, castellano -> Spanish
- portugues, português, portuguese -> Portuguese
- frances, francés, french -> French
- aleman, alemán, german -> German
- italiano, italian -> Italian
- neerlandes, neerlandés, dutch -> Dutch
- chino, mandarin, mandarín -> Mandarin Chinese
- japones, japonés, japanese -> Japanese
- coreano, korean -> Korean

Use title case for languages not listed here.

## Corporate level mapping
Use this mapping when standardizing free-form proficiency descriptions:

| Source wording | Output level |
|---|---|
| native, mother tongue, lengua materna, nativo, nativa, idioma nativo | Native |
| bilingual, bilingue, bilingüe, equally fluent in both languages | Bilingual |
| full professional, fluent, fluido, business fluent, advanced, avanzado, near native, c1, c2 | Full Professional |
| professional, working professional, business level, upper intermediate, b2 | Professional |
| intermediate, intermedio, conversational, working knowledge, limited working, b1 | Limited Working |
| basic, basico, básico, beginner, principiante, elementary, a1, a2 | Elementary |

## Ordering strength
Order levels from strongest to weakest:

1. Native
2. Bilingual
3. Full Professional
4. Professional
5. Limited Working
6. Elementary

## Deduplication examples
If the source says:

```text
Spanish native, English advanced, Inglês fluente, Portuguese basic
```

Return:

```markdown
LANGUAGES
• Spanish — Native
• English — Full Professional
• Portuguese — Elementary
```

If the source says:

```text
Idiomas: Español, Inglés intermedio, Francés B1
```

Return:

```markdown
LANGUAGES
• Spanish — Native
• English — Limited Working
• French — Limited Working
```

## Exclusions
Do not include:
- programming languages such as Java, Python, Go, Rust, Ruby, R, JavaScript, TypeScript, SQL, Scala, C, C++, C#, Kotlin, Swift, PHP, HTML, CSS
- frameworks, databases, cloud tools, or DevOps tools
- soft skills or communication abilities that are not actual languages
