---
name: language-proficiency-standardizer
description: extraction, standardization, and ranking of languages and fluency levels from cvs, resumes, professional profiles, or pasted language notes. use when the user provides plain text, a pdf, word document, txt file, or resume content containing languages such as english, spanish, portuguese, french, german, italian, or others and needs only a clean languages section in markdown under the fixed title languages. normalize informal or multilingual proficiency descriptions into corporate english levels such as native, full professional, professional, limited working, or elementary, and order languages from strongest to weakest proficiency.
---

Languages Section Extractor (Strict Format Contract)
Objective:
Analyze the provided text or resume and generate ONLY the standardized "LANGUAGES" section in Markdown. Convert fluency levels into international enterprise standard nomenclature in English.

Required Output Structure:
LANGUAGES
• [Language Name] — [Standardized Fluency Level]
• [Language Name] — [Standardized Fluency Level]

Strict Formatting Rules:
1. Title: Must be exactly "LANGUAGES" in uppercase.
2. Formatting: Output must be a simple list using standard bullet characters (•). Do NOT use asterisks (*) or numbered lists.
3. Separators: The language and its proficiency level must be separated strictly by a space, an em-dash, and another space: " — ".
4. NO BOLD TEXT: Do NOT use bold text (**) anywhere in this section. All text must be plain text.
5. No intro/outro text: Return ONLY the uppercase title and the bullet points.

Proficiency Standardization & Ordering:
- Map the user's language skills to these exact standard tiers in English:
  * "Native" or "Bilingual" (for mother tongue).
  * "Full Professional" (for fluent/advanced working level).
  * "Professional" (for intermediate-advanced working level).
  * "Limited" (for intermediate/basic conversation).
  * "Elementary" (for basic/beginner level).
- Sort the list strictly from highest proficiency (Native) to lowest proficiency (Elementary).
