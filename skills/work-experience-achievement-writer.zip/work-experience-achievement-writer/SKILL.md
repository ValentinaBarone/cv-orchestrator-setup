---
name: work-experience-achievement-writer
description: extraction, chronological structuring, and senior-level rewriting of technical work experience achievements from engineering cvs, resumes, professional profiles, project notes, or pasted experience text. use when the user provides a full or partial cv in pdf, word, txt, or raw text and needs only a clean work experience section in markdown under the fixed title work experience. focus on backend, cloud, ai, architecture, devops, databases, engineering leadership, scale, and measurable impact. produce each role with 4-5 strong english technical bullets and strict formatting.
---

Work Experience Extractor & Writer (Version 2.0 - Strict Format)
Objective
Extract, structure, and rewrite the candidate's professional history into a standardized, high-impact WORK EXPERIENCE section. Analyze the provided resume, CV, or raw project notes and convert them into an executive technical timeline. 
Every single bullet point must showcase senior-level engineering depth, emphasizing system architecture, backend scalability, cloud-native services, and AI/ML implementations using a strong action-oriented, metrics-driven format.

Required Output Contract
Always return exactly this structure (repeat for each job position):

WORK EXPERIENCE
[Job Title]
[Company Name] — [City, State or Country] | [Month Year] - [Month Year or Present]
• Bullet point 1 focusing on high-level architecture, lead capabilities, or core project.
• Bullet point 3 focusing on data pipeline, processing, API design, or cloud integration.
• Bullet point 2 focusing on specific technical execution and backend development.
• Bullet point 4 focusing on deployment, infrastructure (IaC), CI/CD, or reliability.
• Bullet point 5 focusing on scale, metrics, or measurable business/technical impact.

Formatting Rules (STRICT):
1. The title must be exactly WORK EXPERIENCE in uppercase.
2. Job Title must be on its own line (plain text, no markdown headers, no bold).
3. Company Name, Location, and Dates must be on the next line using the exact separators: " — " (long dash) and " | " (pipe). 
4. The date range separator must be a standard hyphen with spaces: " - ". Example: May 2024 - Sep 2025.
5. Use standard bullet points (•) for the achievements. Do not use asterisks (*). 
6. CRITICAL: Do NOT use bold text (**) inside the bullet points. All text within the bullet points must be plain text.
7. Do not add introductory lines, summaries, or concluding notes. Return only the structured experience block.

Chronological Timeline Alignment (2026 Context):
- You must sort the positions strictly from most recent to oldest based on their end dates.
- Roles that are active up to the present ("Present") must go at the very top.
- If multiple roles are "Present", sort them by their start date (most recent start date first).
- Roles that ended in late 2025 (e.g., Dec 2025) must go strictly below the active "Present" roles.

Bullet Point Construction Rules (The Impact Formula)
Every single bullet point must be written in professional technical English and must strictly adhere to the following formula:
- Action Verb + Architecture/Context + Core Stack + Scale/Result.
- Always start with a strong technical action verb in past tense (e.g., Led, Engineered, Architected, Developed, Implemented, Designed, Migrated). Never use passive openings like "Responsible for...".
- Explicitly weave the technical stack naturally into the achievements (e.g., "using C#/.NET (ASP.NET Core, Entity Framework)", "leveraging LangChain and multi-agent workflows", "deployed on AWS (SageMaker, Lambda, S3)").
- Avoid generic filler text. Focus heavily on keywords relevant to senior engineering: microservices, event-driven architecture, distributed systems, RAG-based systems, serverless, RESTful APIs, high-throughput.
