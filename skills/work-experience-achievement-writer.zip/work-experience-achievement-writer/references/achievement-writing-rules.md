# Achievement Writing Rules

## Output Example

WORK EXPERIENCE
Senior Backend Engineer
Acme Corporation — New York, NY | Jan 2021 - Present
• Architected cloud-native microservices for customer-facing transaction workflows using Java, Spring Boot, Kafka, and AWS, improving platform scalability across enterprise production environments.
• Led API modernization initiatives by refactoring monolithic services into distributed REST and event-driven components, reducing release complexity and strengthening system maintainability.
• Implemented CI/CD pipelines with Docker, Kubernetes, Terraform, and GitHub Actions, accelerating deployment cycles while improving consistency across staging and production environments.
• Optimized PostgreSQL queries, Redis caching strategies, and asynchronous processing patterns, improving response times for high-volume backend services.

## Bullet Formula
Use this structure for every bullet:

1. Strong past-tense action verb.
2. System, architecture, or ownership area.
3. Technical stack or methodology.
4. Scale, measurable result, reliability benefit, delivery outcome, or business impact.

Example patterns:
- Architected [system] using [stack], enabling [scale/impact].
- Led [initiative] across [team/system] with [tools], improving [result].
- Migrated [legacy system] to [modern architecture/cloud], reducing [risk/cost/latency].
- Implemented [automation/pipeline/platform] with [tools], accelerating [delivery/process].
- Optimized [database/service/workflow] through [technique], improving [performance/reliability].

## Strategic Ordering Within Each Role
Order bullets from strongest to supporting:
1. Architecture, platform, or system design.
2. Major delivery or modernization initiative.
3. Cloud, DevOps, automation, reliability, or data/AI work.
4. Performance, scalability, security, or measurable impact.
5. Leadership, mentoring, stakeholder, or cross-functional ownership when relevant.

## Technology Normalization
Use canonical technology names:
- JavaScript, TypeScript, Node.js, React, Angular, Vue.js
- Java, Spring Boot, .NET, C#, Python, Django, FastAPI, Flask
- AWS, Azure, Google Cloud Platform, Docker, Kubernetes, Terraform
- PostgreSQL, MySQL, SQL Server, MongoDB, Redis, Elasticsearch
- Kafka, RabbitMQ, SQS, SNS, Lambda, API Gateway
- GitHub Actions, GitLab CI/CD, Jenkins, Azure DevOps

Do not overload every bullet with every technology. Use the technologies most relevant to that achievement.

## Metrics and Impact
Use exact metrics only when provided or clearly derivable. Acceptable impact language when metrics are unavailable:
- improved scalability
- strengthened reliability
- accelerated delivery cycles
- reduced operational overhead
- enhanced maintainability
- supported enterprise-scale workloads
- increased deployment consistency
- improved observability and incident response
- enabled cloud-native modernization

Avoid fabricated claims such as exact percentages, revenue, user counts, SLA improvements, or latency reductions unless present in the source.

## Quality Checklist
Before finalizing, verify:
- The output begins only with `WORK EXPERIENCE`.
- Each role has job title, company line, and 4-5 bullets.
- The company line uses `Company — Location | Dates`.
- Every bullet starts with `•`.
- No sub-bullets, tables, bolding, explanations, or final notes appear.
- Bullets are written in English and in past tense.
- Every bullet sounds senior, technical, specific, and impact-focused.
