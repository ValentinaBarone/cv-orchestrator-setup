# Additional Experience Rules

## Target style
Write polished English resume bullets for technical achievements that do not belong under a specific employer. The tone should be senior, concise, technical, and impact-oriented.

## Preferred content types
Use this skill for:
- Independent or freelance technical projects.
- Aggregated years of hands-on engineering experience.
- Practical cloud, backend, AI, DevOps, data, or automation projects.
- Portfolio projects, labs, proofs of concept, architecture experiments, and reusable frameworks.
- General technical milestones extracted from a CV that should not be tied to a role.

## Output examples

Input:
```text
Hice varios proyectos con AWS, Docker y Kubernetes. Automatice despliegues y trabaje con microservicios.
```

Output:
```markdown
ADDITIONAL EXPERIENCE
• Designed and deployed cloud-native microservice architectures using AWS, Docker, and Kubernetes, improving delivery consistency across containerized environments.
• Automated deployment workflows and infrastructure operations through CI/CD practices, reducing manual release effort and strengthening production readiness.
```

Input:
```text
Proyectos personales: chatbot con OpenAI, backend en Python, base de datos Postgres, deploy en GCP. Tambien hice integraciones con APIs externas.
```

Output:
```markdown
ADDITIONAL EXPERIENCE
• Built AI-enabled backend applications using Python, OpenAI APIs, PostgreSQL, and GCP, integrating external services into scalable production-style workflows.
• Engineered API-driven automation solutions that connected third-party platforms, streamlined data exchange, and improved extensibility across backend services.
```

## Phrase patterns
- Architected scalable backend services using [stack], supporting [volume/complexity/impact].
- Built production-ready cloud solutions with [cloud/tools], improving [reliability/delivery/performance].
- Automated [workflow/process] through [tools], reducing manual effort and increasing operational consistency.
- Integrated [systems/APIs/platforms] into [architecture], enabling [business/technical outcome].
- Optimized [system/process] by applying [technique/tool], improving [latency/cost/throughput/reliability].
- Established reusable engineering patterns for [domain], accelerating delivery across [systems/teams/projects].

## Level calibration
Junior phrasing:
- Worked on a website using React and Node.js.

Senior rewrite:
- Built full-stack web applications using React, Node.js, and RESTful APIs, delivering maintainable front-end and backend components for production-oriented use cases.

Weak phrasing:
- Used Docker and AWS for deployment.

Senior rewrite:
- Containerized and deployed cloud-based services using Docker and AWS, improving portability, release consistency, and infrastructure scalability.

## Handling missing metrics
Do not invent numbers. Use qualitative senior language when no metric exists:
- large-scale
- high-volume
- cloud-native
- distributed
- production-grade
- enterprise-grade
- reusable
- cross-platform
- fault-tolerant
- scalable
- maintainable
- security-conscious

## Final self-check
The final answer must be copy-paste ready for a resume and contain only:
1. `ADDITIONAL EXPERIENCE`
2. Bullet lines beginning with `•`
