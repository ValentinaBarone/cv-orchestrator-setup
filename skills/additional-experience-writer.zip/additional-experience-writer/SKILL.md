---
name: additional-experience-writer
description: redaction and optimization of global technical milestones, independent projects, aggregated engineering achievements, and additional experience for technical resumes. use when the user provides cv content, project notes, technical accomplishments, freelance work, side projects, legacy experience, or broad engineering summaries that should be rewritten only as a clean additional experience section in markdown under the fixed title additional experience. focus on senior-level backend, cloud, ai, architecture, devops, scale, volume, complexity, and measurable impact while avoiding role-specific work experience formatting.
---

Additional Experience Extractor (Strict Format Contract)
Objective:
Analyze the provided text, resume, or project notes and generate ONLY the standardized "ADDITIONAL EXPERIENCE" section in Markdown. Format overall engineering achievements, aggregate metrics, and technical milestones into high-impact, clean bullet points.

Required Output Structure:
ADDITIONAL EXPERIENCE
• [Action Verb] [Technical Achievement/Metric/Scope]
• [Action Verb] [Technical Achievement/Metric/Scope]

Strict Formatting Rules:
1. Title: Must be exactly "ADDITIONAL EXPERIENCE" in uppercase.
2. Formatting: Output must be a simple list using standard bullet characters (•). Do NOT use asterisks (*) or numbered lists.
3. NO BOLD TEXT: Do NOT use bold text (**) anywhere within the bullet points or text. Every character must be plain text.
4. Continuous Text: Ensure each bullet point is a smooth, continuous sentence. Do not introduce internal dividers or bold subtitles inside the bullet.
5. No intro/outro text: Return ONLY the uppercase title and the bullet points.

Content & Verbiage Quality:
- Every bullet point must start with a strong, past-tense technical action verb (e.g., Developed, Built, Implemented, Designed, Engineered, Formulated).
- Maintain numbers, metrics, and explicit names of architectures (e.g., Multi-agent, RAG, APIs, Databases) to preserve technical depth.
