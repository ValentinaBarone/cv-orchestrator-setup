# Summary Style Reference

## Target Output

The output must begin with the exact title `PROFESSIONAL SUMMARY`, followed by one blank line and then continuous prose paragraphs. Do not use bullets.

## Recommended Length

- Strong CV with 10+ years and rich details: 120-180 words.
- Moderate CV or partial experience text: 80-140 words.
- Sparse input: 50-90 words.

## Phrase Bank

Use phrases like these only when supported by the CV:

- senior backend engineer with extensive experience designing scalable, cloud-native platforms
- technical leader specializing in backend architecture, distributed systems, and cloud infrastructure
- combines hands-on engineering depth with architecture ownership and cross-functional delivery leadership
- experienced in microservices, RESTful APIs, event-driven systems, CI/CD, containerization, and DevOps practices
- background spans enterprise environments, global technology organizations, and high-impact digital transformation initiatives
- strong command of AWS, Azure, GCP, Kubernetes, Docker, Terraform, observability, and automated delivery pipelines
- proven ability to mentor engineers, guide architecture decisions, align stakeholders, and drive reliable software delivery

## Quality Checklist

Before final output, ensure:

1. The title is exactly `PROFESSIONAL SUMMARY`.
2. The body is prose only, with no bullets or labels.
3. The summary references only facts supported by the provided input.
4. Technologies and companies are prioritized by relevance and seniority.
5. The narrative balances keywords, architecture scope, leadership, and business context.
6. There is no contact information, education dump, or full career chronology.

## Example Output

PROFESSIONAL SUMMARY

Senior backend engineer and technical leader with over 10 years of experience designing, modernizing, and delivering scalable software platforms across cloud-native and enterprise environments. Specialized in backend architecture, distributed systems, API design, microservices, and DevOps practices, with strong hands-on experience across technologies such as Java, Python, Node.js, AWS, Kubernetes, Docker, CI/CD pipelines, relational databases, and event-driven integrations.

Experienced working with global organizations and high-impact engineering teams, contributing to complex platform modernization, cloud migration, and digital transformation initiatives. Recognized for combining deep technical execution with architectural ownership, team mentoring, stakeholder collaboration, code quality practices, and delivery leadership across agile environments.
