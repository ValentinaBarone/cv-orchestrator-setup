---
name: cv-contact-header-parser
description: 'extraction and standardization of contact headers from cvs, resumes, curriculums, or pasted resume text. use when the user provides a pdf, word document, txt file, or plain text cv and needs only the candidate identity and contact header returned in exactly two plain-text lines: full name, then location | phone | email | linkedin. focus on personal identity/contact data and ignore experience, education, skills, recruiters, references, company contacts, and unrelated document content.'
---

# CV Contact Header Parser

## Goal
Extract and normalize only the candidate's identity and contact header from a complete CV or resume, even when the document is old, messy, multilingual, or not visually structured.

## Required Output Contract
Always return exactly two lines and nothing else:

[Nombre Completo]
[Ubicación] | [Teléfono] | [Email] | [LinkedIn]

Rules:
- Do not add labels such as `Nombre:`, `Teléfono:`, `Email:`, or `LinkedIn:`.
- Do not add bullets, markdown tables, explanations, confidence scores, or extra blank lines.
- Use a single space on both sides of each pipe separator: ` | `.
- If a field is not found, leave it empty but preserve the separators.
- The second line must always contain four positions: ubicación, teléfono, email, linkedin.

## Extraction Workflow
1. Read the complete document or pasted text.
2. Identify the candidate, not employers, recruiters, references, institutions, or template authors.
3. Prioritize the document header, first page, top contact block, sidebar, footer/header metadata, and signature-like personal data sections.
4. Ignore employment history, education, certifications, projects, skills, publications, references, and company descriptions unless they contain the candidate's own contact details.
5. Extract and normalize exactly these fields: full name, location, phone, email, LinkedIn.
6. Produce the two-line output contract exactly.

## Field Rules

### Full name
- Return the candidate's personal full name in title case or the best natural capitalization for the language.
- Remove honorifics, degree markers, role titles, emojis, and labels.
- Do not include job title or profession in the name line.
- If multiple names appear, prefer the name that is visually/structurally presented as the CV owner near the contact data.

### Location
- Return the most specific candidate location available, such as `City, Country` or `State, Country`.
- Do not infer a location from employer offices, university addresses, references, phone country codes, or job postings.

### Phone
- Normalize ALL phone numbers to E.164 format:
  1. Remove all non-numeric characters (spaces, dashes, parentheses, dots, etc.), except for a leading "+".
  2. If the number does not start with "+", and the country code is identifiable from the location/context, prepend the appropriate international country code (e.g., +1 for USA, +34 for Spain, +49 for Germany).
  3. If the country code is missing and cannot be reliably identified, output the cleaned numeric string with a leading "+" (if applicable) or just the digits.
  4. Ensure the final result has NO spaces, dashes, or parentheses. Example: +34600123456.
- Do not use recruiter, company, reference, or emergency phone numbers.

### Email
- Return a single email address, lowercase.
- Prefer the personal/candidate email near the header.
- Do not return recruiter, company, reference, noreply, or institutional administrative emails.

### LinkedIn
- Return a single LinkedIn profile URL or handle.
- Normalize common formats to a clean URL when possible, for example `linkedin.com/in/usuario` or `https://www.linkedin.com/in/usuario`.

## Ambiguity Rules
- Never invent a missing field.
- When two candidate-like values conflict, choose the value closest to the name/header and contact cluster.
- If a field appears only in a references section, ignore it unless the document clearly says it belongs to the candidate.
- If the document has multiple CVs concatenated, extract only the first candidate.
