# Extraction Rules and Examples

## Header detection signals
Strong signals that a block belongs to the candidate:
- Appears at the very beginning of the CV, on the first page, in a sidebar, or in repeated page header/footer text.
- Contains a person name next to email, phone, city, LinkedIn, portfolio, GitHub, or website.
- Uses labels such as datos personales, contacto, personal information, contact, teléfono, celular, email, correo, linkedin.

Weak or negative signals:
- Appears under experiencia, educación, referencias, empresa, contacto de referencia, recruiter, rrhh, universidad, cliente, proveedor.
- Uses role/company wording such as hiring manager, recruiter, HR, talent acquisition, referencia laboral, supervisor.

## Name normalization examples
- `LIC. JUAN PABLO PEREZ` -> `Juan Pablo Perez`
- `María Laura Gómez - Analista Funcional` -> `María Laura Gómez`
- `CV / Resume: DIEGO A. RODRIGUEZ` -> `Diego A. Rodriguez`

Do not remove meaningful initials when they appear as part of the presented identity.

## Phone examples
Argentina examples:
- `011 15 5555-1234`, with Argentina context -> `+5491155551234`
- `+54 9 351 555-1234` -> `+5493515551234`
- `(0341) 15-555-1234`, with Argentina context -> `+5493415551234`

International examples:
- `+598 99 123 456` -> `+59899123456`
- `+56 9 8765 4321` -> `+56987654321`

Avoid false positives:
- Do not extract ID numbers, DNI, CUIT, postal codes, dates, salary numbers, or certificate IDs as phones.
- Do not extract employer switchboard numbers from experience entries.

## Email examples
- `JUAN.PEREZ@GMAIL.COM` -> `juan.perez@gmail.com`
- `mailto:ana.lopez@hotmail.com` -> `ana.lopez@hotmail.com`

Reject emails such as `rrhh@empresa.com`, `jobs@company.com`, `noreply@platform.com`, unless the context clearly marks it as the candidate's personal contact.

## LinkedIn examples
- `linkedin: /in/juan-perez-123` -> `https://www.linkedin.com/in/juan-perez-123`
- `www.linkedin.com/in/maria-gomez` -> `https://www.linkedin.com/in/maria-gomez`
- `linkedin.com/company/acme` -> reject, because it is not a personal profile.

## Output examples

Complete data:
```text
Juan Pablo Perez
Buenos Aires, Argentina | +5491155551234 | juan.perez@gmail.com | https://www.linkedin.com/in/juan-perez
```

Missing location and LinkedIn:
```text
Ana López
 | +59899123456 | ana.lopez@hotmail.com | 
```

Missing phone:
```text
Diego A. Rodriguez
Rosario, Argentina |  | diego.rodriguez@email.com | https://www.linkedin.com/in/diego-rodriguez
```
